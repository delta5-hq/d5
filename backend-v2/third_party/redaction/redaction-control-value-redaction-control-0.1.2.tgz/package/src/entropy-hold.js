import { RedactionHoldError } from "./errors.js";
import { calculateShannonEntropy, countUniqueCharacters } from "./shannon-entropy.js";

const CANDIDATE_PATTERN = /[A-Za-z0-9+/_-]{16,}={0,2}/gu;
const NON_ALPHABETIC_SECRET_SIGNAL = /[0-9+/]/u;
const ALPHABETIC_SECRET_SIGNAL = /^[A-Za-z]+$/u;
const HOLD_BANDS = Object.freeze([
  defineHoldBand({ minLength: 16, maxLength: 23, minUniqueCharacters: 14, minShannonEntropy: 3.75, requiredSignal: NON_ALPHABETIC_SECRET_SIGNAL }),
  defineHoldBand({ minLength: 16, maxLength: 23, minUniqueCharacters: 14, minShannonEntropy: 3.75, requiredSignal: ALPHABETIC_SECRET_SIGNAL }),
  defineHoldBand({ minLength: 24, maxLength: 31, minUniqueCharacters: 16, minShannonEntropy: 4, requiredSignal: NON_ALPHABETIC_SECRET_SIGNAL }),
  defineHoldBand({ minLength: 24, maxLength: 31, minUniqueCharacters: 18, minShannonEntropy: 4.15, requiredSignal: ALPHABETIC_SECRET_SIGNAL }),
  defineHoldBand({ minLength: 32, maxLength: Infinity, minUniqueCharacters: 16, minShannonEntropy: 4.2 }),
]);

export function assertNoUnresolvedHighEntropyMaterial(text) {
  const candidate = findUnresolvedHighEntropyMaterial(text);

  if (candidate) {
    throw new RedactionHoldError("unresolved-high-entropy", candidate.start, candidate.end);
  }
}

export function findUnresolvedHighEntropyMaterial(text) {
  for (const match of text.matchAll(CANDIDATE_PATTERN)) {
    const candidate = match[0];
    const band = findMatchingHoldBand(candidate);

    if (!band) {
      continue;
    }

    return Object.freeze({
      class: "unresolved-high-entropy",
      start: match.index,
      end: match.index + candidate.length,
    });
  }

  return undefined;
}

function defineHoldBand(band) {
  return Object.freeze(band);
}

function findMatchingHoldBand(candidate) {
  return HOLD_BANDS.find((band) => candidateSatisfiesBand(candidate, band));
}

function candidateSatisfiesBand(candidate, band) {
  return (
    candidate.length >= band.minLength &&
    candidate.length <= band.maxLength &&
    band.requiredSignal?.test(candidate) !== false &&
    countUniqueCharacters(candidate) >= band.minUniqueCharacters &&
    calculateShannonEntropy(candidate) >= band.minShannonEntropy
  );
}
