export class RedactionConfigurationError extends Error {
  constructor(code, message) {
    super(message);
    this.name = "RedactionConfigurationError";
    this.code = code;
  }
}

export class RedactionHoldError extends Error {
  constructor(removalClass, start, end) {
    super("Material requires review before emission.");
    this.name = "RedactionHoldError";
    this.code = "REDACTION_HOLD";
    this.removal = Object.freeze({ class: removalClass, start, end });
  }
}

export class RedactionMaterialError extends Error {
  constructor(materialType) {
    super("Material type is unsafe for redaction.");
    this.name = "RedactionMaterialError";
    this.code = "REDACTION_UNSUPPORTED_MATERIAL";
    this.materialType = materialType;
  }
}
