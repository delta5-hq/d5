# @redaction-control/value-redaction-control

Private value redaction library and standalone checker. This control reduces
exposure; it does not guarantee prevention of disclosure.

## Use

```js
import { createRedactingEmitter } from "@redaction-control/value-redaction-control";

const emitter = createRedactingEmitter({
  registeredValues: ["ExampleValue12345"],
  sink: async (material) => send(material),
});

await emitter.emit("before ExampleValue12345 after");
```

The emitter applies the full value pipeline before the supplied sink receives
material. Returned removal records contain class and position metadata only.
