import { MINIMUM_SAFE_VALUE_LENGTH } from "./version.js";
import { RedactionConfigurationError } from "./errors.js";
import { assertReplacementCanPreserveSafeByteLengths } from "./redaction-output.js";

export function assertSafeRegisteredValue(value, index) {
  if (typeof value !== "string") {
    throw new RedactionConfigurationError(
      "REGISTERED_VALUE_NOT_TEXT",
      `Registered value at index ${index} is unsafe: expected text.`
    );
  }

  if (value.length < MINIMUM_SAFE_VALUE_LENGTH) {
    throw new RedactionConfigurationError(
      "REGISTERED_VALUE_TOO_SHORT",
      `Registered value at index ${index} is unsafe: minimum length is ${MINIMUM_SAFE_VALUE_LENGTH}.`
    );
  }

  if (/\s/u.test(value)) {
    throw new RedactionConfigurationError(
      "REGISTERED_VALUE_CONTAINS_WHITESPACE",
      `Registered value at index ${index} is unsafe: whitespace is not allowed.`
    );
  }
}

export function assertSafeReplacementToken(replacement) {
  if (typeof replacement !== "string") {
    throw new RedactionConfigurationError(
      "REPLACEMENT_NOT_TEXT",
      "Replacement token is unsafe: expected text."
    );
  }

  if (replacement.length < MINIMUM_SAFE_VALUE_LENGTH) {
    throw new RedactionConfigurationError(
      "REPLACEMENT_TOO_SHORT",
      `Replacement token is unsafe: minimum length is ${MINIMUM_SAFE_VALUE_LENGTH}.`
    );
  }

  if (/\s/u.test(replacement)) {
    throw new RedactionConfigurationError(
      "REPLACEMENT_CONTAINS_WHITESPACE",
      "Replacement token is unsafe: whitespace is not allowed."
    );
  }

  assertReplacementCanPreserveSafeByteLengths(replacement);
}

export function normalizeRegisteredValues(values) {
  if (!Array.isArray(values)) {
    throw new RedactionConfigurationError(
      "REGISTERED_VALUES_NOT_ARRAY",
      "Registered values are unsafe: expected an array."
    );
  }

  values.forEach(assertSafeRegisteredValue);

  return [...new Set(values)].sort((left, right) => {
    const lengthOrder = right.length - left.length;
    return lengthOrder === 0 ? left.localeCompare(right) : lengthOrder;
  });
}
