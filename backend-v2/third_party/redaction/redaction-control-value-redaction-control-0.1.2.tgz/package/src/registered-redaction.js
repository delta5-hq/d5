export function findRegisteredValueRemovals(text, registeredValues) {
  const matchers = createRegisteredValueMatchers(registeredValues);
  const removals = [];
  let position = 0;

  while (position < text.length) {
    const match = firstMatchAt(text, position, matchers);

    if (match) {
      removals.push(Object.freeze({
        class: "registered-value",
        start: position,
        end: position + match.length,
      }));
      position += match.length;
      continue;
    }

    position += 1;
  }

  return removals;
}

function createRegisteredValueMatchers(registeredValues) {
  const variants = registeredValues.flatMap(createTransportVariants);
  return [...new Set(variants)].sort((left, right) => right.length - left.length || left.localeCompare(right));
}

function createTransportVariants(value) {
  const jsonEscaped = JSON.stringify(value).slice(1, -1);
  const slashEscaped = jsonEscaped.replaceAll("/", "\\/");

  return [value, jsonEscaped, slashEscaped];
}

function firstMatchAt(text, position, matchers) {
  for (const value of matchers) {
    if (text.startsWith(value, position)) {
      return value;
    }
  }

  return undefined;
}
