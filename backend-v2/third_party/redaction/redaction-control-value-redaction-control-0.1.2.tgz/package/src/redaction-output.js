import { RedactionConfigurationError } from "./errors.js";
import { MINIMUM_SAFE_VALUE_LENGTH } from "./version.js";

export function applyRemovals(text, removals, replacement) {
  const acceptedRemovals = selectNonOverlappingRemovals(removals);
  let output = "";
  let position = 0;

  for (const removal of acceptedRemovals) {
    const removedText = text.slice(removal.start, removal.end);
    output += text.slice(position, removal.start);
    output += createLengthPreservingReplacement(replacement, removedText);
    position = removal.end;
  }

  output += text.slice(position);

  return Object.freeze({
    text: output,
    removals: Object.freeze(acceptedRemovals),
  });
}

export function createLengthPreservingReplacement(replacement, removedText) {
  const byteLength = Buffer.byteLength(removedText, "utf8");
  const output = buildReplacementForByteLength(replacement, byteLength);

  if (output === undefined) {
    throw new RedactionConfigurationError(
      "REPLACEMENT_CANNOT_PRESERVE_BYTE_LENGTH",
      "Replacement token is unsafe: cannot preserve removed byte length."
    );
  }

  return output;
}

export function assertReplacementCanPreserveSafeByteLengths(replacement) {
  const minimumRequiredProbeLength = 1;
  const maximumRequiredProbeLength = MINIMUM_SAFE_VALUE_LENGTH + maximumReplacementCharacterByteLength(replacement);

  for (let byteLength = minimumRequiredProbeLength; byteLength <= maximumRequiredProbeLength; byteLength += 1) {
    if (buildReplacementForByteLength(replacement, byteLength) === undefined) {
      throw new RedactionConfigurationError(
        "REPLACEMENT_CANNOT_PRESERVE_BYTE_LENGTH",
        "Replacement token is unsafe: cannot preserve every safe removed byte length."
      );
    }
  }
}

export function selectNonOverlappingRemovals(removals) {
  const sorted = [...removals].sort(compareRemovals);
  const accepted = [];
  let coveredUntil = 0;

  for (const removal of sorted) {
    if (removal.start < coveredUntil) {
      continue;
    }

    accepted.push(removal);
    coveredUntil = removal.end;
  }

  return accepted;
}

function buildReplacementForByteLength(replacement, byteLength) {
  const characters = [...replacement];
  const states = Array(byteLength + 1).fill(undefined);
  states[0] = "";

  for (let length = 0; length <= byteLength; length += 1) {
    if (states[length] === undefined) {
      continue;
    }

    for (const character of characters) {
      const nextLength = length + Buffer.byteLength(character, "utf8");

      if (nextLength <= byteLength && states[nextLength] === undefined) {
        states[nextLength] = states[length] + character;
      }
    }
  }

  return states[byteLength];
}

function maximumReplacementCharacterByteLength(replacement) {
  return Math.max(...[...replacement].map((character) => Buffer.byteLength(character, "utf8")));
}

function compareRemovals(left, right) {
  if (left.start !== right.start) {
    return left.start - right.start;
  }

  const leftLength = left.end - left.start;
  const rightLength = right.end - right.start;

  if (leftLength !== rightLength) {
    return rightLength - leftLength;
  }

  return removalPriority(left.class) - removalPriority(right.class);
}

function removalPriority(removalClass) {
  return removalClass === "registered-value" ? 0 : 1;
}
