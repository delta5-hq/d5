import { calculateShannonEntropy, countUniqueCharacters } from "./shannon-entropy.js";
import { MINIMUM_SAFE_VALUE_LENGTH } from "./version.js";

const BEARER_PROSE_PATTERN = /(^|[^A-Za-z0-9_])(?:[Bb][Ee][Aa][Rr][Ee][Rr])[\t ]+([A-Za-z0-9+/_=.~-]*[A-Za-z0-9+/_=~-])(?=$|[^A-Za-z0-9+/_=~-])/gdu;
const STANDALONE_BEARER_PATTERN = /^(?:[Bb][Ee][Aa][Rr][Ee][Rr])[\t ]+([A-Za-z0-9+/_=.~-]+)$/du;
const STRUCTURAL_BEARER_VALUE_EVIDENCE = /[0-9+/_=.~-]/u;
const ALPHABETIC_BEARER_VALUE = /^[A-Za-z]+$/u;
const MINIMUM_ALPHABETIC_BEARER_LENGTH = 16;
const MINIMUM_ALPHABETIC_BEARER_UNIQUE_CHARACTERS = 12;
const MINIMUM_ALPHABETIC_BEARER_ENTROPY = 3.25;

export function findBearerProseValueRemovals(text, rule) {
  const removals = [];

  for (const match of text.matchAll(BEARER_PROSE_PATTERN)) {
    const value = match[2];

    if (!isBearerProseCredentialValue(value)) {
      continue;
    }

    const [start, end] = match.indices[2];
    removals.push(Object.freeze({ class: rule.class, start, end }));
  }

  return removals;
}

export function findStandaloneBearerValueRemovals(text, rule) {
  const match = STANDALONE_BEARER_PATTERN.exec(text);

  if (!match || !isStandaloneBearerCredentialValue(match[1])) {
    return [];
  }

  const [start, end] = match.indices[1];
  return [Object.freeze({ class: rule.class, start, end })];
}

function isStandaloneBearerCredentialValue(value) {
  return STRUCTURAL_BEARER_VALUE_EVIDENCE.test(value) || isOpaqueAlphabeticBearerValue(value);
}

function isBearerProseCredentialValue(value) {
  if (value.length < MINIMUM_SAFE_VALUE_LENGTH) {
    return false;
  }

  if (STRUCTURAL_BEARER_VALUE_EVIDENCE.test(value)) {
    return true;
  }

  return isOpaqueAlphabeticBearerValue(value);
}

function isOpaqueAlphabeticBearerValue(value) {
  if (!ALPHABETIC_BEARER_VALUE.test(value)) {
    return false;
  }

  return value.length >= MINIMUM_ALPHABETIC_BEARER_LENGTH
    && countUniqueCharacters(value) >= MINIMUM_ALPHABETIC_BEARER_UNIQUE_CHARACTERS
    && calculateShannonEntropy(value) >= MINIMUM_ALPHABETIC_BEARER_ENTROPY;
}
