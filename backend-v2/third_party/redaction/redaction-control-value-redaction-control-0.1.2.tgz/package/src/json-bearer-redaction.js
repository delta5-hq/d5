import { JSON_SPAN_COMPLETE, JSON_SPAN_MALFORMED, parseJsonSpan } from "./json-span-parser.js";

export function findJsonBearerValueRemovals(text, rule) {
  const scanner = createJsonBearerScanner(text, rule);

  return scanner.findRemovals();
}

function createJsonBearerScanner(text, rule) {
  return {
    findRemovals() {
      const removals = [];
      let cursor = 0;

      while (cursor < text.length) {
        const span = parseJsonSpan(text, cursor, (token) => createBearerRemoval(token, rule));

        if (span.status === JSON_SPAN_COMPLETE) {
          removals.push(...span.removals);
          cursor = span.end;
          continue;
        }

        cursor = span.status === JSON_SPAN_MALFORMED ? span.recoveryEnd : cursor + 1;
      }

      return removals;
    },
  };
}

function createBearerRemoval(token, rule) {
  const match = new RegExp(`^${rule.valuePattern}$`, "du").exec(token.content);

  if (!match?.indices) {
    return [];
  }

  const valueStart = match.indices[1][0];
  const valueEnd = match.indices[1][1];
  const startRange = token.ranges[valueStart];
  const endRange = token.ranges[valueEnd - 1];

  if (!startRange || !endRange) {
    return [];
  }

  return [{
    class: rule.class,
    start: startRange.start,
    end: endRange.end,
  }];
}
