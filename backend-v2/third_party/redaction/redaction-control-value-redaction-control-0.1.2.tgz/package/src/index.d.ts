export type RemovalClass = "registered-value" | "structural-credential" | "unresolved-high-entropy";
export type RedactableScalar = string | number | boolean | bigint | null | undefined;
export type RedactableMaterial = RedactableScalar | readonly RedactableMaterial[] | { readonly [key: string]: RedactableMaterial };
export type RedactedMaterial = RedactableScalar | readonly RedactedMaterial[] | { readonly [key: string]: RedactedMaterial };

export interface RemovalRecord {
  readonly class: RemovalClass;
  readonly start: number;
  readonly end: number;
}

export interface RedactionResult<T = unknown> {
  readonly text: T;
  readonly removals: readonly RemovalRecord[];
}

export interface ValueRedactor {
  redact(material: string): RedactionResult<string>;
  redact(material: RedactableMaterial): RedactionResult<RedactedMaterial>;
}

export interface RegisteredValueRedactor {
  redact(text: string): RedactionResult<string>;
}

export interface ValueRedactorOptions {
  readonly registeredValues?: readonly string[];
  readonly replacement?: string;
}

export interface RegisteredValueRedactorOptions {
  readonly registeredValues: readonly string[];
  readonly replacement?: string;
}

export interface RedactingEmitter {
  emit<T extends RedactableMaterial>(material: T): Promise<{ readonly removals: readonly RemovalRecord[] }>;
}

export interface RedactingEmitterOptions {
  readonly registeredValues?: readonly string[];
  readonly replacement?: string;
  readonly sink: (material: RedactableMaterial) => void | Promise<void>;
}

export declare class RedactionConfigurationError extends Error {
  readonly code: string;
  constructor(code: string, message: string);
}

export declare class RedactionHoldError extends Error {
  readonly code: "REDACTION_HOLD";
  readonly removal: RemovalRecord;
  constructor(removalClass: RemovalClass, start: number, end: number);
}

export declare class RedactionMaterialError extends Error {
  readonly code: "REDACTION_UNSUPPORTED_MATERIAL";
  readonly materialType: string;
  constructor(materialType: string);
}

export declare const RULE_SET_VERSION: string;
export declare const DEFAULT_REPLACEMENT: string;
export declare const MINIMUM_SAFE_VALUE_LENGTH: number;

export declare function createValueRedactor(options?: ValueRedactorOptions): ValueRedactor;
export declare function createRegisteredValueRedactor(options: RegisteredValueRedactorOptions): RegisteredValueRedactor;
export declare function redactValues(material: string, options?: ValueRedactorOptions): RedactionResult<string>;
export declare function redactValues(material: RedactableMaterial, options?: ValueRedactorOptions): RedactionResult<RedactedMaterial>;
export declare function redactRegisteredValues(text: string, registeredValues: readonly string[], replacement?: string): RedactionResult<string>;
export declare function createRedactingEmitter(options: RedactingEmitterOptions): RedactingEmitter;
