import { RedactionMaterialError } from "./errors.js";

export function redactStringLeaves(material, redactString) {
  return transformMaterial(material, redactString, new WeakMap());
}

function transformMaterial(material, redactString, seen) {
  if (typeof material === "string") {
    return redactString(material);
  }

  if (isScalarMaterial(material)) {
    return { material, removals: [] };
  }

  if (Array.isArray(material)) {
    return transformArray(material, redactString, seen);
  }

  if (isPlainObject(material)) {
    return transformPlainObject(material, redactString, seen);
  }

  throw new RedactionMaterialError(materialTypeName(material));
}

function transformArray(array, redactString, seen) {
  if (seen.has(array)) {
    return { material: seen.get(array), removals: [] };
  }

  const output = [];
  const removals = [];
  seen.set(array, output);

  for (const item of array) {
    const result = transformMaterial(item, redactString, seen);
    output.push(result.material);
    removals.push(...result.removals);
  }

  return { material: output, removals };
}

function transformPlainObject(object, redactString, seen) {
  if (seen.has(object)) {
    return { material: seen.get(object), removals: [] };
  }

  const output = {};
  const removals = [];
  seen.set(object, output);

  for (const [key, value] of Object.entries(object)) {
    const keyResult = redactString(key);
    const valueResult = transformMaterial(value, redactString, seen);

    if (Object.prototype.hasOwnProperty.call(output, keyResult.material)) {
      throw new RedactionMaterialError("duplicate-object-key-after-redaction");
    }

    output[keyResult.material] = valueResult.material;
    removals.push(...keyResult.removals, ...valueResult.removals);
  }

  return { material: output, removals };
}

function isScalarMaterial(value) {
  return value === null || ["boolean", "number", "bigint", "undefined"].includes(typeof value);
}

function isPlainObject(value) {
  if (Object.prototype.toString.call(value) !== "[object Object]") {
    return false;
  }

  const prototype = Object.getPrototypeOf(value);
  return prototype === Object.prototype || prototype === null;
}

function materialTypeName(value) {
  return Object.prototype.toString.call(value).slice(8, -1).toLowerCase();
}
