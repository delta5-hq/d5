export const RULE_SET_VERSION = "redaction-rules-v2";
export const DEFAULT_REPLACEMENT = "[redacted]";
export const MINIMUM_SAFE_VALUE_LENGTH = 8;
