import { findJsonBearerValueRemovals } from "./json-bearer-redaction.js";
import { findBearerProseValueRemovals, findStandaloneBearerValueRemovals } from "./bearer-prose-redaction.js";
import { createStructuralMatcher, STRUCTURAL_REDACTION_RULES } from "./rules.js";

export function findStructuralRemovals(text, rules = STRUCTURAL_REDACTION_RULES) {
  const removals = [];

  for (const rule of rules) {
    if (rule.matcher === "json-bearer-string-value") {
      removals.push(...findJsonBearerValueRemovals(text, rule));
      continue;
    }

    if (rule.matcher === "bearer-prose-value") {
      removals.push(...findBearerProseValueRemovals(text, rule));
      continue;
    }

    if (rule.matcher === "standalone-bearer-value") {
      removals.push(...findStandaloneBearerValueRemovals(text, rule));
      continue;
    }

    const matcher = createStructuralMatcher(rule);

    for (const match of text.matchAll(matcher)) {
      const [start, end] = match.indices[rule.valueGroup ?? 1];

      removals.push(createRemoval(rule.class, start, end));
    }
  }

  return removals;
}

function createRemoval(removalClass, start, end) {
  return Object.freeze({ class: removalClass, start, end });
}
