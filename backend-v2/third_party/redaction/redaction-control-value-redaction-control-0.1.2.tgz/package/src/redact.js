import { DEFAULT_REPLACEMENT } from "./version.js";
import { assertSafeReplacementToken, normalizeRegisteredValues } from "./safe-values.js";
import { assertNoUnresolvedHighEntropyMaterial } from "./entropy-hold.js";
import { applyRemovals } from "./redaction-output.js";
import { findRegisteredValueRemovals } from "./registered-redaction.js";
import { findStructuralRemovals } from "./structural-redaction.js";
import { redactStringLeaves } from "./material-redaction.js";

export function createValueRedactor(options = {}) {
  const registeredValues = normalizeRegisteredValues(options.registeredValues ?? []);
  const replacement = options.replacement ?? DEFAULT_REPLACEMENT;
  assertSafeReplacementToken(replacement);

  return Object.freeze({
    redact(material) {
      return redactValues(material, { registeredValues, replacement });
    },
  });
}

export function createRegisteredValueRedactor(options) {
  const registeredValues = normalizeRegisteredValues(options?.registeredValues ?? []);
  const replacement = options?.replacement ?? DEFAULT_REPLACEMENT;
  assertSafeReplacementToken(replacement);

  return Object.freeze({
    redact(text) {
      return redactRegisteredValues(String(text), registeredValues, replacement);
    },
  });
}

export function redactValues(material, options = {}) {
  const registeredValues = normalizeRegisteredValues(options.registeredValues ?? []);
  const replacement = options.replacement ?? DEFAULT_REPLACEMENT;
  assertSafeReplacementToken(replacement);

  const result = redactStringLeaves(material, (text) => redactText(text, registeredValues, replacement));
  assertMaterialHasNoUnresolvedHighEntropy(result.material);

  return Object.freeze({
    text: result.material,
    removals: Object.freeze(result.removals),
  });
}

export function redactRegisteredValues(text, registeredValues, replacement = DEFAULT_REPLACEMENT) {
  const safeValues = normalizeRegisteredValues(registeredValues);
  assertSafeReplacementToken(replacement);

  return applyRemovals(String(text), findRegisteredValueRemovals(String(text), safeValues), replacement);
}

function redactText(text, registeredValues, replacement) {
  const removals = [
    ...findRegisteredValueRemovals(text, registeredValues),
    ...findStructuralRemovals(text),
  ];

  const result = applyRemovals(text, removals, replacement);
  return { material: result.text, removals: result.removals };
}

function assertMaterialHasNoUnresolvedHighEntropy(material) {
  redactStringLeaves(material, (text) => {
    assertNoUnresolvedHighEntropyMaterial(text);
    return { material: text, removals: [] };
  });
}
