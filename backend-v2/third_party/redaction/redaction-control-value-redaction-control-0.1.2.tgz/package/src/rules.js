import { MINIMUM_SAFE_VALUE_LENGTH, RULE_SET_VERSION } from "./version.js";
import { findJsonBearerValueRemovals } from "./json-bearer-redaction.js";
import { findBearerProseValueRemovals, findStandaloneBearerValueRemovals } from "./bearer-prose-redaction.js";

const TOKEN_LEFT = "(?:^|[^A-Za-z0-9_])";
const TOKEN_RIGHT = "(?=$|[^A-Za-z0-9_])";
const BASE64URL = "[A-Za-z0-9_-]";
const BEARER_VALUE = "[A-Za-z0-9+/_=.~-]";
const HORIZONTAL_WHITESPACE = "[\\t ]";
const AUTHORIZATION_HEADER_LABEL = `(?<![A-Za-z0-9_-])(?:${caseInsensitiveLiteral("Authorization")}|${caseInsensitiveLiteral("Proxy-Authorization")})`;
const BEARER_SCHEME = caseInsensitiveLiteral("Bearer");
const BASIC_SCHEME = caseInsensitiveLiteral("Basic");
const TOKEN_SCHEME = caseInsensitiveLiteral("Token");
const BASIC_VALUE = `[A-Za-z0-9+/]{${MINIMUM_SAFE_VALUE_LENGTH},}={0,2}`;
const TOKEN_SCHEME_VALUE = `[A-Za-z0-9._~-]{${MINIMUM_SAFE_VALUE_LENGTH},}`;
const AUTHORIZATION_COLON_PREFIX = `${AUTHORIZATION_HEADER_LABEL}${HORIZONTAL_WHITESPACE}*:${HORIZONTAL_WHITESPACE}*`;
const AUTHORIZATION_ASSIGNMENT_PREFIX = `${AUTHORIZATION_HEADER_LABEL}${HORIZONTAL_WHITESPACE}*=${HORIZONTAL_WHITESPACE}*`;
const AUTHORIZATION_VALUE_PREFIX = `${AUTHORIZATION_HEADER_LABEL}${HORIZONTAL_WHITESPACE}*[:=]${HORIZONTAL_WHITESPACE}*`;
const DONOR_SERVICE_TOKEN = [
  "gh[pousr]_[A-Za-z0-9_]{10,255}",
  "github_pat_[A-Za-z0-9_]{10,255}",
  "gl(?:pat|dt|rt|cr|agent|soat)[-_][A-Za-z0-9_-]{10,255}",
  "npm_[A-Za-z0-9_]{10,255}",
].join("|");
const URL_SCHEME = "[A-Za-z][A-Za-z0-9+.-]*";
const URL_USERINFO = "[^\\s:@/?#]+(?::[^\\s@/?#]+)?";
const URL_AUTHORITY_HOST = "[^\\s/?#@]+";

export const STRUCTURAL_REDACTION_RULES = Object.freeze([
  defineRule({
    id: "structural-rule-001",
    class: "structural-credential",
    version: RULE_SET_VERSION,
    pattern: `${TOKEN_LEFT}(${DONOR_SERVICE_TOKEN})${TOKEN_RIGHT}`,
    positive: "token = ghp_abcdefghij",
    negative: "tokenization embeds aghp_abcdefghijz inside ordinary prose",
  }),
  defineRule({
    id: "structural-rule-002",
    class: "structural-credential",
    version: RULE_SET_VERSION,
    pattern: `${TOKEN_LEFT}(xox[baprs]-[A-Za-z0-9-]{20,255})${TOKEN_RIGHT}`,
    positive: "worker=xoxb-123456789012-abcdefghijklmnopqr",
    negative: "The phrase xoxb appears as a marker-shaped word fragment.",
  }),
  defineRule({
    id: "structural-rule-003",
    class: "structural-credential",
    version: RULE_SET_VERSION,
    pattern: `${TOKEN_LEFT}(AKIA[0-9A-Z]{16})${TOKEN_RIGHT}`,
    positive: "key: AKIAIOSFODNN7EXAMPLE",
    negative: "AKIA identifiers in documentation must be complete before removal.",
  }),
  defineRule({
    id: "structural-rule-004",
    class: "structural-credential",
    version: RULE_SET_VERSION,
    pattern: "(-----BEGIN [A-Z ]*PRIVATE KEY-----[\\s\\S]+?-----END [A-Z ]*PRIVATE KEY-----)",
    positive: "pem=-----BEGIN PRIVATE KEY-----\nQUJDREVGR0hJSktMTU5PUA==\n-----END PRIVATE KEY-----",
    negative: "-----BEGIN PUBLIC KEY-----\nQUJDREVGRw==\n-----END PUBLIC KEY-----",
  }),
  defineRule({
    id: "structural-rule-005",
    class: "structural-credential",
    version: RULE_SET_VERSION,
    pattern: `${URL_SCHEME}:\\/\\/(${URL_USERINFO})@${URL_AUTHORITY_HOST}`,
    positive: "remote=ssh://UrlPassw0rdValue@example.test/path",
    negative: "remote=git@example.test:path/repo.git and https://example.test/path",
  }),
  defineRule({
    id: "structural-rule-006",
    class: "structural-credential",
    version: RULE_SET_VERSION,
    pattern: `${TOKEN_LEFT}(eyJ${BASE64URL}{7,}\\.${BASE64URL}{10,}\\.${BASE64URL}{10,})${TOKEN_RIGHT}`,
    positive: "jwt=eyJaaaaaaaa.abcdefghij.abcdefghij",
    negative: "A long dotted identifier like abcdefghij.abcdefghij.abcdefghij is ordinary prose.",
  }),
  defineRule({
    id: "structural-rule-007",
    class: "structural-credential",
    version: RULE_SET_VERSION,
    pattern: `${AUTHORIZATION_COLON_PREFIX}${BEARER_SCHEME}${HORIZONTAL_WHITESPACE}+(${BEARER_VALUE}+)${TOKEN_RIGHT}`,
    positive: "Authorization: Bearer 7",
    negative: `Deauthorization: Bearer a
Authorization: Bearer
ordinary`,
  }),
  defineRule({
    id: "structural-rule-012",
    class: "structural-credential",
    version: RULE_SET_VERSION,
    pattern: `${AUTHORIZATION_ASSIGNMENT_PREFIX}${BEARER_SCHEME}${HORIZONTAL_WHITESPACE}+(${BEARER_VALUE}+)${TOKEN_RIGHT}`,
    positive: "Authorization=Bearer 7",
    negative: `Deauthorization=Bearer a
Authorization=Bearer
ordinary`,
  }),
  defineRule({
    id: "structural-rule-010",
    class: "structural-credential",
    version: RULE_SET_VERSION,
    matcher: "standalone-bearer-value",
    positive: "Bearer 7",
    negative: `Bearer holidays
Bearer a is mentioned in prose without an owned string boundary.`,
  }),
  defineRule({
    id: "structural-rule-013",
    class: "structural-credential",
    version: RULE_SET_VERSION,
    matcher: "bearer-prose-value",
    positive: "log line: called api with Bearer abcdefg8 then returned ok",
    negative: `log line: called api with Bearer short7 then returned ok
log line: the Bearer document remains ordinary prose`,
  }),
  defineRule({
    id: "structural-rule-011",
    class: "structural-credential",
    version: RULE_SET_VERSION,
    matcher: "json-bearer-string-value",
    valuePattern: `${BEARER_SCHEME}${HORIZONTAL_WHITESPACE}+(${BEARER_VALUE}+)`,
    positive: "{\"Authorization\":\"Bearer 7\"}",
    negative: "The phrase \"Bearer 7\" is quoted prose.",
  }),
  defineRule({
    id: "structural-rule-014",
    class: "structural-credential",
    version: RULE_SET_VERSION,
    pattern: `${AUTHORIZATION_VALUE_PREFIX}${BASIC_SCHEME}${HORIZONTAL_WHITESPACE}+(${BASIC_VALUE})${TOKEN_RIGHT}`,
    positive: "Proxy-Authorization: Basic YWxhZGRpbjpvcGVuc2VzYW1l",
    negative: `Proxy-Deauthorization: Basic short
Authorization: Basic short`,
  }),
  defineRule({
    id: "structural-rule-015",
    class: "structural-credential",
    version: RULE_SET_VERSION,
    pattern: `${AUTHORIZATION_VALUE_PREFIX}${TOKEN_SCHEME}${HORIZONTAL_WHITESPACE}+(${TOKEN_SCHEME_VALUE})${TOKEN_RIGHT}`,
    positive: "Authorization: Token abcdefgh",
    negative: `Deauthorization: Token abcdefgh
Authorization: Token short7`,
  }),
  defineRule({
    id: "structural-rule-008",
    class: "structural-credential",
    version: RULE_SET_VERSION,
    pattern: `${TOKEN_LEFT}(sk-(?:proj-|svcacct-)?[A-Za-z0-9_-]{32,255})${TOKEN_RIGHT}`,
    positive: "openai=sk-proj-abcdefghijklmnopqrstuvwxyzABCDEF0123456789",
    negative: "The text sk-proj-short is not a complete credential.",
  }),
  defineRule({
    id: "structural-rule-009",
    class: "structural-credential",
    version: RULE_SET_VERSION,
    pattern: `${TOKEN_LEFT}(AIza[0-9A-Za-z_-]{35})${TOKEN_RIGHT}`,
    positive: "google=AIzaAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA",
    negative: "AIza is an incomplete prefix inside ordinary documentation.",
  }),
]);

export function assertRuleSetIntegrity(rules = STRUCTURAL_REDACTION_RULES) {
  const ids = new Set();

  for (const rule of rules) {
    assertText(rule.id, "Rule id is required.");
    assertText(rule.class, "Rule class is required.");
    assertText(rule.version, "Rule version is required.");
    assertMatcher(rule);
    assertText(rule.positive, "Rule positive example is required.");
    assertText(rule.negative, "Rule negative example is required.");

    if (ids.has(rule.id)) {
      throw new Error("Rule id must be unique.");
    }

    assertRuleMatchesPositive(rule);
    assertRulePreservesNegative(rule);
    ids.add(rule.id);
  }
}

export function createStructuralMatcher(rule) {
  return new RegExp(rule.pattern, "gdu");
}

function caseInsensitiveLiteral(value) {
  return [...value]
    .map((character) => (/[A-Za-z]/u.test(character) ? `[${character.toUpperCase()}${character.toLowerCase()}]` : escapePatternCharacter(character)))
    .join("");
}

function escapePatternCharacter(character) {
  return character.replace(/[\\^$.*+?()[\]{}|]/gu, "\\$&");
}

function defineRule(rule) {
  return Object.freeze({ ...rule });
}

function assertText(value, message) {
  if (typeof value !== "string" || value.length === 0) {
    throw new Error(message);
  }
}

function assertMatcher(rule) {
  if (rule.matcher === "json-bearer-string-value") {
    assertText(rule.valuePattern, "Rule value pattern is required.");
    return;
  }

  if (rule.matcher === "bearer-prose-value") {
    return;
  }

  if (rule.matcher === "standalone-bearer-value") {
    return;
  }

  assertText(rule.pattern, "Rule pattern is required.");
}

function assertRuleMatchesPositive(rule) {
  if (rule.matcher === "json-bearer-string-value") {
    if (findJsonBearerValueRemovals(rule.positive, rule).length === 0) {
      throw new Error(`Rule ${rule.id} must match its positive example.`);
    }

    return;
  }

  if (rule.matcher === "bearer-prose-value") {
    if (findBearerProseValueRemovals(rule.positive, rule).length === 0) {
      throw new Error(`Rule ${rule.id} must match its positive example.`);
    }

    return;
  }

  if (rule.matcher === "standalone-bearer-value") {
    if (findStandaloneBearerValueRemovals(rule.positive, rule).length === 0) {
      throw new Error(`Rule ${rule.id} must match its positive example.`);
    }

    return;
  }

  const matches = [...rule.positive.matchAll(createStructuralMatcher(rule))];

  if (matches.length === 0 || !matches.some((match) => typeof match[1] === "string" && match[1].length > 0)) {
    throw new Error(`Rule ${rule.id} must match its positive example.`);
  }
}

function assertRulePreservesNegative(rule) {
  if (rule.matcher === "json-bearer-string-value") {
    if (findJsonBearerValueRemovals(rule.negative, rule).length > 0) {
      throw new Error(`Rule ${rule.id} must preserve its negative example.`);
    }

    return;
  }

  if (rule.matcher === "bearer-prose-value") {
    if (findBearerProseValueRemovals(rule.negative, rule).length > 0) {
      throw new Error(`Rule ${rule.id} must preserve its negative example.`);
    }

    return;
  }

  if (rule.matcher === "standalone-bearer-value") {
    if (findStandaloneBearerValueRemovals(rule.negative, rule).length > 0) {
      throw new Error(`Rule ${rule.id} must preserve its negative example.`);
    }

    return;
  }

  if (createStructuralMatcher(rule).test(rule.negative)) {
    throw new Error(`Rule ${rule.id} must preserve its negative example.`);
  }
}
