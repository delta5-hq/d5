import { createValueRedactor } from "./redact.js";

export function createRedactingEmitter(options) {
  if (typeof options?.sink !== "function") {
    throw new TypeError("A sink function is required.");
  }

  if ("redactor" in options) {
    throw new TypeError("Unsupported emitter option: redactor.");
  }

  const redactor = createValueRedactor({
    registeredValues: options.registeredValues ?? [],
    replacement: options.replacement,
  });
  const sink = options.sink;

  return Object.freeze({
    async emit(material) {
      const result = redactor.redact(material);
      await sink(result.text);
      return Object.freeze({ removals: result.removals });
    },
  });
}
