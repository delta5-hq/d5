export const JSON_SPAN_COMPLETE = "complete";
export const JSON_SPAN_MALFORMED = "malformed";
export const JSON_SPAN_NOT_JSON = "not-json";

export function parseJsonSpan(text, position, collectStringRemovals) {
  if (!canStartJsonSpan(text[position])) {
    return notJsonSpan();
  }

  const value = parseJsonValue(text, position, collectStringRemovals);

  if (value.status === JSON_SPAN_MALFORMED) {
    return value;
  }

  if (value.status !== JSON_SPAN_COMPLETE) {
    return notJsonSpan();
  }

  if (!acceptsSpanBoundary(text, position, value.end)) {
    return text[position] === "\"" ? malformedSpan(value.end) : notJsonSpan();
  }

  return value;
}

function parseJsonValue(text, position, collectStringRemovals) {
  const start = skipJsonWhitespace(text, position);
  const character = text[start];

  if (character === "\"") {
    return parseJsonStringValue(text, start, collectStringRemovals);
  }

  if (character === "{") {
    return parseJsonObject(text, start, collectStringRemovals);
  }

  if (character === "[") {
    return parseJsonArray(text, start, collectStringRemovals);
  }

  return parseJsonScalar(text, start);
}

function parseJsonObject(text, position, collectStringRemovals) {
  const removals = [];
  let cursor = skipJsonWhitespace(text, position + 1);

  if (text[cursor] === "}") {
    return completeSpan(cursor + 1, removals);
  }

  while (cursor < text.length) {
    const key = parseJsonStringValue(text, cursor, collectStringRemovals);

    if (key.status !== JSON_SPAN_COMPLETE) {
      return malformedSpan(recoverElementEnd(text, cursor, collectStringRemovals) ?? cursor);
    }

    removals.push(...key.removals);
    cursor = skipJsonWhitespace(text, key.end);

    if (text[cursor] !== ":") {
      return malformedSpan(cursor);
    }

    const value = parseJsonValue(text, cursor + 1, collectStringRemovals);

    if (value.status !== JSON_SPAN_COMPLETE) {
      return malformedSpan(value.status === JSON_SPAN_MALFORMED ? value.recoveryEnd : cursor + 1);
    }

    removals.push(...value.removals);
    cursor = skipJsonWhitespace(text, value.end);

    if (text[cursor] === "}") {
      return completeSpan(cursor + 1, removals);
    }

    if (text[cursor] !== ",") {
      return malformedSpan(cursor);
    }

    cursor = skipJsonWhitespace(text, cursor + 1);
  }

  return malformedSpan(cursor);
}

function parseJsonArray(text, position, collectStringRemovals) {
  const removals = [];
  let cursor = skipJsonWhitespace(text, position + 1);

  if (text[cursor] === "]") {
    return completeSpan(cursor + 1, removals);
  }

  while (cursor < text.length) {
    const value = parseJsonValue(text, cursor, collectStringRemovals);

    if (value.status !== JSON_SPAN_COMPLETE) {
      return malformedSpan(value.status === JSON_SPAN_MALFORMED ? value.recoveryEnd : cursor);
    }

    removals.push(...value.removals);
    cursor = skipJsonWhitespace(text, value.end);

    if (text[cursor] === "]") {
      return completeSpan(cursor + 1, removals);
    }

    if (text[cursor] !== ",") {
      return malformedSpan(cursor);
    }

    cursor = skipJsonWhitespace(text, cursor + 1);
  }

  return malformedSpan(cursor);
}

function recoverElementEnd(text, position, collectStringRemovals) {
  const value = parseJsonValue(text, position, collectStringRemovals);

  if (value.status === JSON_SPAN_COMPLETE) {
    return value.end;
  }

  if (value.status === JSON_SPAN_MALFORMED) {
    return value.recoveryEnd;
  }

  return undefined;
}

function parseJsonStringValue(text, position, collectStringRemovals) {
  const string = parseJsonStringToken(text, position);

  if (string.status !== JSON_SPAN_COMPLETE) {
    return string;
  }

  return completeSpan(string.token.end, collectStringRemovals(string.token));
}

function parseJsonStringToken(text, position) {
  if (text[position] !== "\"") {
    return notJsonSpan();
  }

  let cursor = position + 1;
  let content = "";
  let malformed = false;
  const ranges = [];

  while (cursor < text.length) {
    if (text[cursor] === "\\") {
      const escaped = parseEscapedCharacter(text, cursor);

      if (!escaped) {
        malformed = true;
        cursor = Math.min(cursor + 2, text.length);
        continue;
      }

      if (!malformed) {
        content += escaped.character;
        ranges.push({ start: cursor, end: escaped.end });
      }

      cursor = escaped.end;
      continue;
    }

    if (text[cursor] === "\"") {
      if (malformed) {
        return malformedSpan(cursor + 1);
      }

      return completeStringToken({
        content,
        ranges,
        end: cursor + 1,
      });
    }

    if (isUnescapedControlCharacter(text[cursor])) {
      malformed = true;
      cursor += 1;
      continue;
    }

    if (!malformed) {
      content += text[cursor];
      ranges.push({ start: cursor, end: cursor + 1 });
    }

    cursor += 1;
  }

  return malformedSpan(cursor);
}

function parseJsonScalar(text, position) {
  const match = /^(?:-?(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE][+-]?\d+)?|true|false|null)/u.exec(text.slice(position));

  if (!match) {
    return notJsonSpan();
  }

  return completeSpan(position + match[0].length, []);
}

function completeSpan(end, removals) {
  return { status: JSON_SPAN_COMPLETE, end, removals };
}

function completeStringToken(token) {
  return { status: JSON_SPAN_COMPLETE, token };
}

function malformedSpan(recoveryEnd) {
  return { status: JSON_SPAN_MALFORMED, recoveryEnd };
}

function notJsonSpan() {
  return { status: JSON_SPAN_NOT_JSON };
}

function canStartJsonSpan(character) {
  return character === "\"" || character === "{" || character === "[";
}

function acceptsSpanBoundary(text, start, end) {
  if (text[start] === "\"") {
    return onlyJsonWhitespace(text.slice(0, start)) && onlyJsonWhitespace(text.slice(end));
  }

  return !touchesJsonContainerBoundary(text[start - 1]) && !touchesJsonContainerBoundary(text[end]);
}

function onlyJsonWhitespace(text) {
  return [...text].every((character) => isJsonWhitespace(character));
}

function skipJsonWhitespace(text, position) {
  let cursor = position;

  while (isJsonWhitespace(text[cursor])) {
    cursor += 1;
  }

  return cursor;
}

function isJsonWhitespace(character) {
  return character === "\t" || character === "\n" || character === "\r" || character === " ";
}

function touchesJsonContainerBoundary(character) {
  return character === "\"" || character === "{" || character === "[";
}

function parseEscapedCharacter(text, position) {
  const escaped = text[position + 1];

  if (escaped === undefined) {
    return undefined;
  }

  if (["\"", "\\", "/"].includes(escaped)) {
    return { character: escaped, end: position + 2 };
  }

  if (escaped === "b") {
    return { character: "\b", end: position + 2 };
  }

  if (escaped === "f") {
    return { character: "\f", end: position + 2 };
  }

  if (escaped === "n") {
    return { character: "\n", end: position + 2 };
  }

  if (escaped === "r") {
    return { character: "\r", end: position + 2 };
  }

  if (escaped === "t") {
    return { character: "\t", end: position + 2 };
  }

  if (escaped !== "u") {
    return undefined;
  }

  const digits = text.slice(position + 2, position + 6);

  if (!/^[0-9A-Fa-f]{4}$/u.test(digits)) {
    return undefined;
  }

  return { character: String.fromCharCode(Number.parseInt(digits, 16)), end: position + 6 };
}

function isUnescapedControlCharacter(character) {
  return character.charCodeAt(0) <= 0x1f;
}
